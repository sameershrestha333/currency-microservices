package com.microservice.currencyconversionservice.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.currencyconversionservice.entity.CurrencyConversion;
import com.microservice.currencyconversionservice.service.CurrencyConversionService;

@RestController
public class CurrencyConversionController {

	@Value("${server.port}")
	private int port;

	@Autowired
	private CurrencyConversionService service;

	@GetMapping("/currency-conversion/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion convertCurreny(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {

		/*
		 * CurrencyConversion currencyConversion = new CurrencyConversion(1001L, from,
		 * to, BigDecimal.valueOf(115), quantity, BigDecimal.valueOf(1150), port);
		 */
		CurrencyConversion currencyConversion = service.getCurrencyConsersion(from, to, quantity);
		currencyConversion.setPort(port);
		return currencyConversion;
	}

	@GetMapping("/currency-conversion-feign/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion convertCurrenyFeign(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {
		CurrencyConversion currencyConversion = service.getCurrencyConsersionFeign(from, to, quantity);
		currencyConversion.setPort(port);
		return currencyConversion;
	}
}
