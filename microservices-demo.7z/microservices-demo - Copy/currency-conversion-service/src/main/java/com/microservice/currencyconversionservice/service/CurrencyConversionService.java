package com.microservice.currencyconversionservice.service;

import java.math.BigDecimal;

import com.microservice.currencyconversionservice.entity.CurrencyConversion;

public interface CurrencyConversionService {

	CurrencyConversion getCurrencyConsersion(String from, String to, BigDecimal quantity);

	CurrencyConversion getCurrencyConsersionFeign(String from, String to, BigDecimal quantity);}
