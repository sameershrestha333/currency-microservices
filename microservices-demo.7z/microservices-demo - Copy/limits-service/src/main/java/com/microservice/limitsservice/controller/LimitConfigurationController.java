package com.microservice.limitsservice.controller;

import com.microservice.limitsservice.config.Configuration;
import com.microservice.limitsservice.model.LimitConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/limits")
public class LimitConfigurationController {

    private Configuration limitConfig;

    @Autowired
    public LimitConfigurationController(Configuration limitConfig) {
        this.limitConfig = limitConfig;
    }

    @GetMapping()
    public LimitConfiguration getLimitConfiguration() {
        LimitConfiguration limitConfiguration = new LimitConfiguration(limitConfig.getMaximum(), limitConfig.getMinimum());
        return limitConfiguration;

    }

    /*@GetMapping()
    public String getLimitConfiguration() {
        return "Hello ";

    }*/
}
