INSERT INTO exchange_value(id,conversion_multiple,currency_from,port,currency_to) VALUES
(10001,105,'USD',8000,'NEP');

INSERT INTO exchange_value(id,conversion_multiple,currency_from,port,currency_to) VALUES
(10002,130,'EUR',8000,'NEP');

INSERT INTO exchange_value(id,conversion_multiple,currency_from,port,currency_to) VALUES
(10003,85,'AUD',8000,'NEP');
INSERT INTO exchange_value(id,conversion_multiple,currency_from,port,currency_to) VALUES
(10004,1.6,'INR',8000,'NEP');
